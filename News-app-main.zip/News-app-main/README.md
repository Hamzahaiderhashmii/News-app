# news_app

A new Flutter project.

## ScreenShots

<img src="https://github.com/Marriiamm/News-app/assets/125306697/cf856d35-27b9-4dc2-8845-1c39c75849fe.jpg" width="260" height="600">
<img src="https://github.com/Marriiamm/News-app/assets/125306697/a809cf9b-dfd6-4057-a87c-9880d512adcd.jpg" width="260" height="600">
<img src="https://github.com/Marriiamm/News-app/assets/125306697/00e739ee-4de8-4e9a-89e9-610ca27133fc.jpg" width="260" height="600">
