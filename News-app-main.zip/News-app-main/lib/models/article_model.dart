class ArticleModel {
  final String? image;
  final String title;
  final String? suptitle;
  final String? url;
 

  ArticleModel({this.url,required this.image, required this.title, required this.suptitle});
}