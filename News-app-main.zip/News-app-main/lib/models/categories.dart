class caregories{
  final String categoryName;
  final String image;

  const caregories({required this.categoryName, required this.image});
}